public class Hello {

	public static void main(String[] args) {
		int value1 = 1, value2 = 2;
		int value3 = value1*value2*value2;
		
		System.out.println(value3);

	}

}
