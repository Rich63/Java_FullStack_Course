public class Hello {
	public static void main(String[] args) {
		/*
		int value1 = 9/2;
		float value2 = 10f/6f;
		double value3 = 10d/6d;
		System.out.println("value  1 = "+ value1);
		System.out.println("value  2 = "+ value2);
		System.out.println("value  3 = "+ value3);
		*/
	    int marker = 512;
	    double percentage = marker * 0.46f;
	    
	    System.out.println("percentage:"+percentage);
		
		
	}
}
