package org.studyeasy;

public class Hello {

	public static void main(String[] args) {
		
       float f = 10.532f;
       long l = (long) f;
       System.out.println(l);
	}

}
