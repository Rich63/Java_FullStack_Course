public class Hello {
	public static void main(String[] args) {
		boolean var = false;
		System.out.println(var);

		char var1 = '\u00A7';
		System.out.println(var1);
		
	}
}
