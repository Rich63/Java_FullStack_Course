public class Hello {
	public static void main(String[] args) {
		String var = new String("Hello world");
		System.out.println(var);
		
	}

}
